"""Prepare the static website for a repository path or a custom domain."""
from pathlib import Path
from urllib.parse import urljoin,urlsplit
import argparse,html,json,os,re,shutil
ROOT=Path(__file__).resolve().parents[2]
parser=argparse.ArgumentParser()
parser.add_argument("--base-url",default=os.environ.get("MFB_BASE_URL",""))
parser.add_argument("--output",default=str(ROOT/"_site"))
args=parser.parse_args()
base=args.base_url.rstrip("/")+"/"
parts=urlsplit(base)
if parts.scheme!="https" or not parts.netloc or parts.query or parts.fragment:
 raise SystemExit("Indica una dirección HTTPS válida mediante MFB_BASE_URL o --base-url.")
out=Path(args.output).resolve()
if out==ROOT or out in ROOT.parents or out.is_symlink():
 raise SystemExit("Elige un directorio de salida independiente.")
if out.exists():shutil.rmtree(out)
out.mkdir(parents=True)
for entry in ROOT.iterdir():
 if entry==out or entry.name.startswith((".","_")):continue
 if entry.is_dir() and (entry.name=="assets" or (entry/"index.html").exists()):
  shutil.copytree(entry,out/entry.name)
 elif entry.is_file() and entry.suffix==".html":
  shutil.copy2(entry,out/entry.name)
cfg=json.loads((ROOT/"site-config.json").read_text())
def h(s):return html.escape(str(s),quote=True)
def https_url(value):
 try:
  p=urlsplit(str(value))
  return str(value) if p.scheme=="https" and p.hostname else ""
 except ValueError:return ""
email=str(cfg.get("contactEmail","")).strip()
if email and not re.fullmatch(r"[^@\s<>]+@[^@\s<>]+\.[^@\s<>]+",email):
 raise SystemExit("Revisa el correo de contacto en site-config.json.")
public={"name":"MFB Corporation","contactEmail":email,"supportUrl":https_url(cfg.get("supportUrl",""))}
(out/"assets/settings.js").write_text("window.MFB_CONFIG = "+json.dumps(public,ensure_ascii=False).replace("<","\\u003c")+";\n")
sponsor=cfg.get("sponsor")
sponsor_html=""
if isinstance(sponsor,dict) and https_url(sponsor.get("url","")):
 sponsor_html='<aside class="sponsor-band container"><span>PATROCINIO</span><div><b>'+h(sponsor.get("name",""))+'</b><p>'+h(sponsor.get("description",""))+'</p></div><a class="btn secondary" href="'+h(sponsor["url"])+'" rel="sponsored noopener noreferrer" target="_blank">Conocer más</a></aside>'
urls=[]
for p in sorted(out.rglob("*.html")):
 rel=p.relative_to(out)
 page_path=rel.parent.as_posix().strip(".")
 route=(page_path+"/" if page_path else "") if rel.name=="index.html" else rel.as_posix()
 url=urljoin(base,route)
 raw=p.read_text()
 raw=re.sub(r'<link\b[^>]*rel="canonical"[^>]*>',"",raw)
 raw=re.sub(r'<meta\b[^>]*property="og:(?:url|image)"[^>]*>',"",raw)
 meta='<link rel="canonical" href="'+h(url)+'"><meta property="og:url" content="'+h(url)+'"><meta property="og:image" content="'+h(urljoin(base,"assets/social.png"))+'">'
 raw=raw.replace("</head>",meta+"</head>")
 def schema(m):
  data=json.loads(m.group(1));data["url"]=url
  return '<script type="application/ld+json">'+json.dumps(data,ensure_ascii=False).replace("<","\\u003c")+'</script>'
 raw=re.sub(r'<script type="application/ld\+json">(.*?)</script>',schema,raw)
 def absolute(m):
  value=html.unescape(m.group(2))
  if value and not urlsplit(value).scheme and not value.startswith("//"):
   value=urljoin(url,value)
  return m.group(1)+'="'+h(value)+'"'
 raw=re.sub(r'\b(href|src|action)="([^"]*)"',absolute,raw)
 if public["supportUrl"]:
  support='<a href="'+h(public["supportUrl"])+'" rel="noopener noreferrer" target="_blank">Apoyar el proyecto</a>'
  raw=raw.replace("<div><b>El proyecto</b>","<div><b>El proyecto</b>"+support)
 if email and page_path=="contacto":
  replacement='<p>Escríbenos a <a href="mailto:'+h(email)+'">'+h(email)+'</a>.</p>'
  raw=re.sub(r'<div class="notice neutral">.*?El canal de envío directo todavía no está habilitado\..*?</div>',replacement,raw,flags=re.S)
 if sponsor_html:
  raw=raw.replace("</main>",sponsor_html+"</main>")
  raw=raw.replace("Los patrocinios todavía no están habilitados.","Hay un patrocinio activo. Para nuevas colaboraciones, utiliza el canal de contacto del proyecto.")
 p.write_text(raw)
 if not re.search(r'<meta\s+name="robots"\s+content="[^"]*noindex',raw):
  urls.append(url)
(out/"sitemap.xml").write_text('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'+''.join("<url><loc>"+h(url)+"</loc></url>" for url in urls)+"</urlset>")
(out/"robots.txt").write_text("User-agent: *\nAllow: /\nDisallow: "+urlsplit(urljoin(base,"lanzamiento/")).path+"\nSitemap: "+urljoin(base,"sitemap.xml")+"\n")
(out/".nojekyll").touch()
print("Listo:",len(list(out.rglob("*.html"))),"páginas preparadas para",base)
